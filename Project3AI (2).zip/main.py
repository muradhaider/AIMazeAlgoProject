#Murad Haider Comp 151 Project 3
import sys
import random
import copy

INITIAL_RATE = 0.2
Input_Num = 200
THRESHOLD = 0.5

COORDINATES = ["Latitude", "Longitude"]
CONTINENTS = ["Africa", "America", "Antarctica", "Asia", "Arctic", "Atlantic","Australia", "Europe",  "Indian", "Pacific"]


class Neuron:
    def __init__(self, name):
        self.name = name
        self.true_positives = 0
        self.true_negatives = 0
        self.false_positives = 0
        self.false_negatives = 0

    def print_neuron(self):
        total = self.true_positives + self.true_negatives + self.false_positives + self.false_negatives

        print("Neuron:" + str(self.name))
        print("Correct:" + str(round(100*(self.true_positives + self.true_negatives)/total, 2)) + "%")

        print("True Positive:" + str(round(100 * (self.true_positives/total), 2)) + "%")
        print("True Negative:" + str(round(100 * (self.true_negatives/total), 2)) + "%")
        print("False Positive:" + str(round(100 * (self.false_positives/total), 2)) + "%")
        print("False Negative:" + str(round(100 * (self.false_negatives/total), 2)) + "%\n")


class Data:
    def __init__(self, lat_coord, long_coord, continents):
        self.latitude = lat_coord
        self.longitude = long_coord
        self.continent = continents

    def __str__(self):
        return str(self.latitude) + ", " + str(self.longitude) + ", " + self.continent


class Machine:
    def __init__(self):
        self.map = {}
        weight_index = 0
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            input_map = {}
            for cont in CONTINENTS:
                cur_weight = random.randint(0, 1)
                input_map[cont] = cur_weight
                weight_index += 1
            self.map[coord] = input_map

    def update_weights(self, data):
        global THRESHOLD, INITIAL_RATE, CONTINENTS
        for cont in CONTINENTS:
            lat_weight = self.map["Latitude"][cont]
            long_weight = self.map["Longitude"][cont]

            output = int((data.latitude * lat_weight + data.longitude * long_weight) > THRESHOLD)
            
            correct = int(cont == data.continent)

            self.map["Latitude"][cont] = lat_weight + INITIAL_RATE * (correct - output) * data.latitude
            self.map["Longitude"][cont] = long_weight + INITIAL_RATE * (correct - output) * data.longitude

    def get_weights(self):
        weights = ""
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            for cont in CONTINENTS:
                weights += (str(self.map[coord][cont]) + "\t")
        weights = weights[0:len(weights)-1]
        return weights

    def store_weights(self, filename):
        weights = self.get_weights()
        file = open(filename, "w")
        file.write(weights)
        file.close()

    def load_weights(self, filename):
        file = open(filename, "r")
        line = file.readline().split("\t")
        for i in range(len(line)):
            line[i] = float(line[i])
        file.close()
        self.map = {}
        weight_index = 0
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            input_map = {}
            for cont in CONTINENTS:
                cur_weight = line[weight_index]
                input_map[cont] = cur_weight
                weight_index += 1
            self.map[coord] = input_map

    def print_weights(self):
        weights = ""
        global CONTINENTS, COORDINATES
        for coord in COORDINATES:
            print(coord + "\n")
            for cont in CONTINENTS:
                weights += cont + ": " + (str(self.map[coord][cont]) + "\t")
        print(weights)

    def get_guesses(self, data):
        global CONTINENTS, THRESHOLD
        guesses = {}
        for cont in CONTINENTS:
            lat_weight = self.map["Latitude"][cont]
            long_weight = self.map["Longitude"][cont]
            guess_output = int((data.latitude * lat_weight + data.longitude * long_weight) > THRESHOLD)
            guesses[cont] = guess_output
        return guesses


def read_in_file_data(datafile):
    data = []
    file = open(datafile, "r")
    for line in file:
        cur_line = line.strip("\n").split("\t")
        cur_data = Data((float(cur_line[0]) + 90)/180, (float(cur_line[1]) + 180)/360, cur_line[2])
        data.append(cur_data)

    file.close()
    return data


def main():
    training_data = read_in_file_data("nnTrainData.txt")
    testing_data = read_in_file_data("nnTestData.txt")
    machine = Machine()
    while True:
        print("1. Neural Network Algo")
        print("2. Store coords into a file")
        print("3. Load coords")
        print("4. Run test data file")
        print("5. Print coords")
        print("6. Exit")
        choice = input()
        if int(float(choice)) == 1:
            machine = neural_network_algorithm(training_data, machine)
        elif int(float(choice)) == 2:
            weight_file = input("Enter the input file name\t")
            machine.store_weights(weight_file)
            del weight_file
        elif int(float(choice)) == 3:
            print("1. Load coord from input file")
            print("2. Load random coords")
            print("3. Exit")
            choice2 = input()
            if int(float(choice2)) == 1:
                weight_file = input("Input the name of the file")
                machine.load_weights(weight_file)
                del weight_file
            elif int(float(choice2)) == 2:
                machine = Machine()
            else:
                sys.exit(0)
        elif int(float(choice)) == 4:
            neurons = run_testing_data(testing_data, machine)
            global CONTINENTS
            for cont in CONTINENTS:
                neurons[cont].print_neuron()
        elif int(float(choice)) == 5:
            machine.print_weights()
        else:
            sys.exit(0)


def neural_network_algorithm(training_data, machine):
    global Input_Num
    for i in range(Input_Num):
        cur_dataset = copy.deepcopy(training_data)
        while len(cur_dataset) > 0:
            cur_data = cur_dataset.pop(random.randint(0, len(cur_dataset)-1))
            machine.update_weights(cur_data)
    return machine


def run_testing_data(test_data, machine):
    global CONTINENTS
    neurons = {}
    for cont in CONTINENTS:
        neurons[cont] = Neuron(cont)
    for data in test_data:
        neurons = run_data(data, machine, neurons)
    return neurons


def run_data(data, machine, neurons):
    global CONTINENTS
    guesses = machine.get_guesses(data)
    for cont in CONTINENTS:
        guess = guesses[cont]
        actual = int(data.continent == cont)
        if guess == 1 and actual == 1:
            neurons[cont].true_positives += 1
        elif guess == 1 and actual == 0:
            neurons[cont].false_positives += 1
        elif guess == 0 and actual == 1:
            neurons[cont].false_negatives += 1
        elif guess == 0 and actual == 0:
            neurons[cont].true_negatives += 1
    return neurons


if __name__ == "__main__":
    main()
