Needed: 
Python
import os
import time
import argparse
import copy
import sys
import numpy as np


How to run the program (Command Line Aruguments): 
"Please enter the name of the file you'd like to read followed by the number of chromosomes, generations, your choice of elitist or tournament, the percentage of what should be formed using selection in this generation and finally the mutation rate"
 
(python main.py genAlgData1.txt 10 5 elitist 0.5 kpoint 0.50)




