#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import time
import argparse
import copy
import sys
import numpy as np


class Chrom:

    def __init__(
        self,
        lowerbound1,
        upperbound1,
        lowerbound2,
        upperbound2,
        preferred,
        fitness = 0
        ):
        self.lowerbound1 = lowerbound1
        self.upperbound1 = upperbound1
        self.lowerbound2 = lowerbound2
        self.upperbound2 = upperbound2
        self.preferred = preferred
        self.fitness = fitness
#get the input file and use it to calculate hte fitness and print it out later on
    def fitnessCalc(self, input_data):
        self.fitness = 0
        fitnesses = []
        for line in input_data:
            match = int(self.lowerbound1 <= line[0] <= self.upperbound1
                        and self.lowerbound2 <= line[1]
                        <= self.upperbound2)  # equals 0 or 1 depending on whether there is a match or not
            profit = int(2 * (int((2 * self.preferred - 1)) * line[2] > 0) - 1)  
            # equals -1 or 1 depending on whether a profit is made
            new_fitness = match * profit * round(abs(line[2]), 2)  # if not a match, this equals 0, if profit is made, it is positive, if profit is lost, it is negative.
            self.fitness += new_fitness
            fitnesses.append(new_fitness)
        self.fitness = round(sum(fitnesses), 2)

    def __str__(self):
        return str(self.lowerbound1) + '\t' + str(self.upperbound1) + '\t' + str(self.lowerbound2) + '\t' + str(self.upperbound2) + '\t' + str(self.preferred) + '\tfitness: ' + str(self.fitness) + '\n'
#Below was my orignial approach similar to the snaccer and parser project from 147
#However, that plan fell through and I decided to do the above calculations instead due to multiple things not printing 

###    def __init__(self, genes = [0, 0, 0, 0, 0], fitness = 0):
 #       self.genes = genes
 #       self.fitness = fitness

    # # calculates fitness ##
 #   def fitnessCalc(self, file):
 #       match = False
 #       reader = open(file, "r")
 #       lines = reader.readlines()
 #       for line in lines:
 #           data = line.split('\t')
 #           data[2] = (data[2])[:-1]
  #          if float(self.genes[0]) <= float(data[0]) <= float(self.genes[1]):
  #              if float(data[1]) >= float(self.genes[2]) and float(data[1]) <= float(self.genes[3]):
  #                  match = True
  #                  profit = data[2]
  #                  if self.genes[4] == 1:
  #                      self.fitness = self.fitness + float(profit)
  #                 else:
  #                      self.fitness = self.fitness + -1 * float(profit)
  #          if not match:
  #              self.fitness = -5000

  #  def __str__(self):
  #      return "%f %f %f %f %d" % (self.genes[0], self.genes[1], self.genes[2], self.genes[3], self.genes[4])
# test = initialGeneration(12)
# for c in test:
#    print(c)

# fitness testing
# fake = [1, 2, 3, 4, 0]
# c = Chromosome(fake)
# c.fitnessCalc("GA_debug.txt")
# print(c.fitness)

def arg_parse():
    if len(sys.argv) != 8:
        raise ValueError("Please enter the name of the file you'd like to read followed by the number of chromosomes, generations, your choice of elitist or tournament, the percentage of what should be formed using selection in this generation and finally the mutation rate"
                         )
#parse arguments into the right variables above and raise error if things are not correct
    return (
        sys.argv[1],
        int(sys.argv[2]),
        int(sys.argv[3]),
        sys.argv[4],
        float(sys.argv[5]),
        sys.argv[6],
        float(sys.argv[7]),
        )

#take in command line arguments 
##Decided to use a command line!
# def userParameters():
#    verification = os.listdir()
#    filename = input("Please enter the name of the file you'd like to read: ")
#    while filename not in verification:
#        filename = input("File not found! Try again: ")
#    chromosomes = input("Please enter the number of chromosomes for each generation: ")
 #   generations = input("Now enter how many generations you'd like to watch: ")
#    selection = input("Which selection algorithm will you be using? (elitist/tournament): ")
#    percentage = input("Enter in a percentage of what should be formed using selection in this generation. \n"
#                       "The remaining percentage will be formed using crossover. Mutation will then be applied \n"
#                       "to randomly selected genes from within that generation. Percentage (1 to 100): ")
#    crossover = input("Now select which crossover algorithm (uniform/kpoint): ")
#    rate = input("Finally, enter the initial rate of mutation: ")
#    return filename, chromosomes, generations, selection, percentage, crossover, rate

def randomnum():
    return round(np.random.normal(loc=0.0, scale=1.15, size=None), 2)
    #use this to get the random number in order ot fill the values for the chromosomes 


# def checkChrom(data):
#    if data[0] > data[1]:
#        data[0], data[1] = data[1], data[0]
#    if data[2] > data[3]:
#       data[2], data[3] = data[3], data[2]

def intitialGeneration(num_chroms):
  #here we have the start gen and we seed the random number for the random number generator in order for it to spit out the list of the chromosomes generated 
    chroms = []
    np.random.seed(int(time.time()))
    for i in range(num_chroms):
        random_val1 = [randomnum(), randomnum()]
        random_val1.sort()
        random_val2 = [randomnum(), randomnum()]
        random_val2.sort()
        #this will give each chromosome their respected value and then it will provide those chromosomes with the values given above in the bellow block of code. 
        new_chroms = Chrom(lowerbound1 = random_val1[0],
                           upperbound1 = random_val1[1],
                           lowerbound2 = random_val2[0],
                           upperbound2 = random_val2[1],
                           preferred = np.random.randint(0, 2))
        chroms.append(new_chroms)
              #we then need to add the new chromosome to the list of chromosomes and return chroms
    return chroms

#this is for the debug file, it will read in the file and will return the debug file data as an array
def debug_data(debug_file):
    data = []
    file = open(debug_file)
    GA_debug = file.readlines()
    for line in GA_debug:
        clean_line = line.split('\n')[0].split('\t')
        for i in range(len(clean_line)):
            clean_line[i] = float(clean_line[i])
        data.append(clean_line)
    return data


def new_offspring(parents, uniform_or_kpoint):
  #Here we are going to use this function in order to return the children of the chromosomes and it will raise an error if there is an incorrect input. 
    entry = uniform_or_kpoint.lower()
    if entry != 'uniform' and entry != 'kpoint':
      #make the decision between kpoint and uniform, raises error when input is not lowercase or spelt correctly as seen in the if statment parameters
        raise ValueError("Please enter the name of the file you'd like to read followed by the number of chromosomes, generations, your choice of elitist or tournament, the percentage of what should be formed using selection in this generation and finally the mutation rate"
                         )
        sys.exit()
    if uniform_or_kpoint.lower() == 'uniform':
        new_child = Chrom(parents[np.random.randint(0, 2)].lowerbound1,
                          parents[np.random.randint(0, 2)].upperbound1,
                          parents[np.random.randint(0, 2)].lowerbound2,
                          parents[np.random.randint(0, 2)].upperbound2,
                          parents[np.random.randint(0, 2)].preferred)
    else:

        new_child = Chrom(parents[0].lowerbound1,
                          parents[0].upperbound1,
                          parents[1].lowerbound2,
                          parents[1].upperbound2, 
                          parents[1].preferred)

    return new_child


# uniform testing
# print("\n\n\n")
# print("uniform:\n")
# attempt = uniform(test, 5)
# for p in attempt:
#   print(p)

def mutation(chroms, mutation_rate):
    for i in range(len(chroms)):
        Bottom = np.random.uniform(0, 1) <= mutation_rate
        Top = np.random.uniform(0, 1) <= mutation_rate
        Bottom1 = np.random.uniform(0, 1) <= mutation_rate
        Top1 = np.random.uniform(0, 1) <= mutation_rate
        reacclimate = np.random.uniform(0, 1) <= mutation_rate
        #bool
#this will take the mutation rate and te list of chromosomes. The output is the list of mutated chromosomes which is based off of the users input in the command line. 
        if Bottom:
            chroms[i].lowerbound1 = int(Bottom) * randomnum() + \
                 int(not Bottom) * chroms[i].lowerbound1
            while chroms[i].lowerbound1 >= chroms[i].upperbound1:
                chroms[i].lowerbound1 = int(Bottom) * randomnum() + \
                     int(not Bottom) * chroms[i].lowerbound1

        if Top:
            chroms[i].upperbound1 = int(Top) * randomnum() + \
                  int(not Bottom) * chroms[i].upperbound1
            while chroms[i].upperbound1 <= chroms[i].lowerbound1:
                chroms[i].upperbound1 = int(Top) * randomnum() + \
                     int(not Top) * chroms[i].upperbound1

        if Bottom1:
            chroms[i].lowerbound2 = int(Bottom1) * randomnum() + \
                 int(not Bottom1) * chroms[i].lowerbound2
            while chroms[i].lowerbound2 >= chroms[i].upperbound2:
                chroms[i].lowerbound2 = int(Bottom1) * randomnum() + \
                     int(not Bottom1) * chroms[i].lowerbound2

        if Top1:
            chroms[i].upperbound1 = int(Top1) * randomnum() + \
                 int(not Top1) * chroms[i].upperbound2
            while chroms[i].upperbound2 <= chroms[i].lowerbound2:
                chroms[i].upperbound2 = int(Top1) * randomnum() + \
                     int(not Top1) * chroms[i].upperbound2

        chroms[i].preferred = int(reacclimate) * np.random.randint(0, 2) + \
             int(not  reacclimate) * chroms[i].preferred
    return chroms


def fitness(chroms, input_data):
  #assign the fitness calclations value for the chromosomes 
    for chrom in chroms:
        chrom.fitnessCalc(input_data)
    return chroms

def fitnessfunction(n):
  #sorting the chroms
    return n.fitness

def selection(chroms, elitist_or_tournament, x):
  #select the fittest chrom and check the users input to see if they want to do elitist or tournament and for errors, in this case again has to be lowercase and spelt correctly. 
    entry = elitist_or_tournament.lower()
    fittest_chroms = []
    if entry != 'elitist' and entry != 'tournament':
        raise ValueError("Please enter the name of the file you'd like to read followed by the number of chromosomes, generations, your choice of elitist or tournament, the percentage of what should be formed using selection in this generation and finally the mutation rate"
                         )

        sys.exit()
    if entry == 'elitist':
        chroms.sort(reverse=True, key=fitnessfunction)
        fittest_chroms = chroms[0:x]
    else:

        while(len(fittest_chroms) < x):
            chromosome1 = chroms[np.random.randint(0, len(chroms))]
            chromosome2 = chroms[np.random.randint(0, len(chroms))]
            fittest_chroms.append(max(chromosome1, chromosome2, key=fitnessfunction))
    print("Fittest Chromosomes: ")
    print_chroms(fittest_chroms)
    return fittest_chroms


def print_chroms(chroms):
  #print the values in the list of the chroms 
    fitnesses = []
    for chrom in chroms:
        fitnesses.append(chrom.fitness)
        print(chrom)
    print('\n')
    print('max: ' + str(max(fitnesses)))
    print('min: ' + str(min(fitnesses)))
    print('mean:' + str(round(sum(fitnesses) / len(fitnesses), 2)))


def new_gen(halfchromy, num_chroms, uniform_or_kpoint):
  #new generation of chroms based off of the old initial generation. 
    chroms = copy.deepcopy(halfchromy)
    while len(chroms) < num_chroms:
        parents = [halfchromy[np.random.randint(0, len(halfchromy))],
                   halfchromy[np.random.randint(0, len(halfchromy))]]
        new_child = new_offspring(parents, uniform_or_kpoint)
        chroms.append(new_child)
    return chroms


def main():
    debug_file, num_chroms, num_generations, elitistortournament, selection_rate, uniform_or_kpoint,  mutation_rate = arg_parse()
    data = debug_data(debug_file)
    chroms = intitialGeneration(num_chroms)
    num_produced = int(float(num_chroms*selection_rate))
    chroms = fitness(chroms, data)
    print_chroms(chroms)

    for i in range(num_generations):
        print('Generation ' + str(i + 1) + ': ')
        chroms = selection(chroms, elitistortournament, num_produced)
        #selection function used to determine what would be used and what generations would survive
        chroms = new_gen(chroms, num_chroms, uniform_or_kpoint)
        #the production of the new chroms based off the old ones 
        chroms = mutation(chroms, mutation_rate)
        #mutation function in order to mutate the genes that needed to be mutated
        chroms = fitness(chroms, data)
        #fitness function to find the fitness
        print_chroms(chroms)


# tournament testing
# print("\n\n\n")
# print("tournament:\n")
# gg = tournament(test, 5)
# for g in gg:
#    print(g)

# elitist testing
# print("\n\n\n")
# print("elitist:\n")
# uuugh = elitist(test, 5)
# for u in uuugh:
#     print(u)

# kpoint testing
# print("\n\n\n")
# print("kpoint:\n")
# wow = kpoint(test, 5)
# for w in wow:
#    print(w)

# print("\n\n\n")
# print("mutation:\n")
# mutation(test, 0.2)
# for c in test:
#    print(c)"""

# split, mergeLists, and mergeSort taken from
# https://medium.com/@amirziai/merge-sort-walkthrough-with-code-in-python-e4f76d90a4ea
    # General case
    # index_left = index_right = 0
    # list_merged = []
    # list_len_target = len(left) + len(right)
    # while len (list_merged) < list_len_target:
        # if left[index_left].fitness <= right[index_right].fitness:
            # list_merged.append(left[index_left])
            # index_left += 1
        # else:
            # list_merged.append(right[index_right])
            # index_right += 1

        # if index_right == len(right):
            # list_merged += left[index_left:]
            # break
        # elif index_left == len(left):
            # list_merged += right[index_right:]
            # break

    # return list_merged

    # filename, chromosomes, generations, selection, percentage, crossover, rate = userParameters()
    # newGen = initialGeneration(chromosomes)
    # for i in range(len(initialGeneration(chromosomes))):
        # for j in newGen:
        #    j.fitnessCalc(filename)
        # numSelectedChroms = int(chromosomes) * float(percentage)/100
        # numCrossoverChroms = int(chromosomes) - numSelectedChroms
        # if selection == "elitist":
        #    s = elitist(newGen, numSelectedChroms)
        # if selection == "tournament":
        #    s = tournament(newGen, numSelectedChroms)

        # if crossover == "uniform":
            # c = uniform(newGen, numCrossoverChroms)
        # if crossover == "kpoint":
            # c = kpoint(newGen, numCrossoverChroms)

        # newGen = s + c

        # i_rate = int(rate)

        # mutation(newGen, i_rate)

        # if i % 10 == 0:
           # mergeSort(newGen)
            # print(newGen[0])
           # print(newGen[len(newGen) // 2])
            # print(newGen[-1])

if __name__ == '__main__':
    main()
